package com.android.spinnerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

// Main Activity implements Adapter view
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    // create array of Strings
    // and store name of countries
    String[] country = { "Canada", "India", "Nepal", "Japan", "China", "Australia", "Germany", "Belgium"};
    Spinner spinner;  // declare Spinner

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get spinner by it's Id
        spinner = findViewById(R.id.spinner);
        // apply OnItemSelectedListener on it which tells which item of spinner is clicked
        spinner.setOnItemSelectedListener(this);

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,country);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(arrayAdapter);

    }

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(getApplicationContext(),country[i] , Toast.LENGTH_LONG).show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        /* TODO Auto-generated method stub */
    }
}