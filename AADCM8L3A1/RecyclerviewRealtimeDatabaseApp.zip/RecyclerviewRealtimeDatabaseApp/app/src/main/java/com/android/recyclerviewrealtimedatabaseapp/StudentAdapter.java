package com.android.recyclerviewrealtimedatabaseapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
// This is StudentAdapter class which is extending RecyclerView.In order to implement recycler view we need Adapter.
public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    Context context;  // declare context
    ArrayList<Student> studentArrayList;  // declare ArrayList of Student
    // create constructor of StudentAdapter.
    public StudentAdapter(Context context, ArrayList<Student> studentArrayList) {
        this.context = context;
        this.studentArrayList = studentArrayList;
    }
    // these are few method which we need to implement.
    @NonNull
    @Override  // this method is used to create view
    public StudentAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // views are created with the help of LayoutInflater
        View view = LayoutInflater.from(context).inflate(R.layout.items,parent,false); // items is inflated.
        return new ViewHolder(view); // return view
    }

    @Override  // this method is used to bind the data or you can say insert the data into the views
    public void onBindViewHolder(@NonNull StudentAdapter.ViewHolder holder, int position) {
        Student student = studentArrayList.get(position); // will set the data on particular position
        holder.fullName.setText(student.getName());   // will set full name from Student by getting it with the help of getName method.
        holder.emailId.setText(student.getEmail());  // will set email from Student by getting it with the help of getEmail method.
    }

    @Override // this method is will return total number of data.
    public int getItemCount() {
        return studentArrayList.size();
    }

    // this class will helps us to find the view or fetch the view from our items layout
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView fullName, emailId;  // declare textview name and email
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.name);  // find name by its id
            emailId = itemView.findViewById(R.id.email);  // find email by its id

        }
    }
}
