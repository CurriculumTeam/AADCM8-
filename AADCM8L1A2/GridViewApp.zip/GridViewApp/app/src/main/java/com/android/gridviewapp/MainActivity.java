package com.android.gridviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;

// this MainActivity is created automatically when you created your project
public class MainActivity extends AppCompatActivity {
    GridView gridView;  // declare gridView
    String[] number = new String[30];  // declare array

    @Override  // This method is main method which is created automatically, inside this method we write our code.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // populating array number
        for(int i = 0; i< number.length;i++){
            number[i] = "Number " + i;
        }
        // get gridview by it's Id
        gridView = findViewById(R.id.grid_view);
        // ArrayAdapter is used for displaying data.
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,number);
        gridView.setAdapter(arrayAdapter);  //  setting data to view.

    }
}