package com.android.dataretrievingapp;

public class Student {
    String name,email,number,schoolName;
    public Student(String name, String email, String number, String schoolName) {
        this.name = name;
        this.email = email;
        this.number = number;
        this.schoolName = schoolName;
    }
    public Student() {  // empty constructor, select none while creating constructor.

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getNumber() {
        return number;
    }
    public void setNumber(String number) {
        this.number = number;
    }
    public String getSchoolName() {
        return schoolName;
    }
    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
}
