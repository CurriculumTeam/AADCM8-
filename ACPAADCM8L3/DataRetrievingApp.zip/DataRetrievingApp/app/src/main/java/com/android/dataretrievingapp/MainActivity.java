package com.android.dataretrievingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

// This MainActivity class is created automatically when you created your project
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;  // declare recyclerview
    ArrayList<Student> studentArrayList;  // declare arraylist of student
    DatabaseReference databaseReference;  // declaring databaseReference
    StudentAdapter studentAdapter;    // declare StudentAdapter which you created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // finding recyclerview by its id.
        recyclerView = findViewById(R.id.recycler_view);
        // getting the reference of database, here Students is parent node of real-time database you check from your firebase console inside real-time database.
        databaseReference = FirebaseDatabase.getInstance().getReference("Students");
        studentArrayList = new ArrayList<>(); // creating object of student arraylist
        recyclerView.setHasFixedSize(true); // when we are sure that change of item will not affect height & width of recyclerview, we can set this.
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // setLayoutManager is responsible for setting layout of items.

        // add addValueEventListener on databaseReference to read the data at a path and listen for changes
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override  // onDataChange method is to read a static snapshot of the contents at a given path.This method is triggered when the listener is attached.
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // get the student object and use the values to update the UI.Loop is used because we have more than one data.
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                    Student student = snapshot.getValue(Student.class);
                    studentArrayList.add(student);
                }
                 studentAdapter = new StudentAdapter(MainActivity.this,studentArrayList);// object of StudentAdapter is created and MainActivity and studentArrayList are passed.
                 recyclerView.setAdapter(studentAdapter);// with the help of setAdapter studentAdapter is set to recycler view
            }

            @Override  // when it failed to load data a message will be shown with the help of Toast
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Failed to Retrieve", Toast.LENGTH_SHORT).show();
            }
        });
    }
}