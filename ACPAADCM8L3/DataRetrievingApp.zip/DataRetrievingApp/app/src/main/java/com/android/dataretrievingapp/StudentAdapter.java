package com.android.dataretrievingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
// This is StudentAdapter class which is extending RecyclerView.In order to implement recycler view we need Adapter.
public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    Context context;  // declare context
    ArrayList<Student> studentArrayList;  // declare ArrayList of Student

    // create constructor of StudentAdapter.
    public StudentAdapter(Context context, ArrayList<Student> studentArrayList) {
        this.context = context;
        this.studentArrayList = studentArrayList;
    }
    // these are few method which we need to implement.
    @NonNull
    @Override   // this method is used to create view
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.items,parent,false); // items are inflated.
        return new ViewHolder(view); // return view
    }

    @Override  // this method is used to bind the data or you can say insert the data into the views
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student student = studentArrayList.get(position); // will set the data on particular position
        holder.fullName.setText(student.getName()); // will set full name from Student by getting it with the help of getName method.
        holder.emailId.setText(student.getEmail());  // will set email from student by getting it with getEmail method.
        holder.phoneNumber.setText(student.getNumber());  // will set phone number
        holder.schoolName.setText(student.getSchoolName());  // will set school name
    }

    @Override // this method is will return total number of data.
    public int getItemCount() {
        return studentArrayList.size();
    }
    // this class will helps us to find the view or fetch the view from our items layout
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView fullName, emailId,phoneNumber,schoolName;  // declare textview name,email,phone number,school name
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.name);  // find name by its id
            emailId = itemView.findViewById(R.id.email);  // find email by its id
            phoneNumber = itemView.findViewById(R.id.phone_number);  // get phone number by its id
            schoolName = itemView.findViewById(R.id.school_name);   // get school name by its id

        }
    }
}
