package com.android.banneradsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
// this class is created automatically when you create your project.
public class MainActivity extends AppCompatActivity {
    private AdView mAdView;  // declare AdView

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialize MobileAds
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        // get AdView by it's Id
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();  // create object of AdRequest
        mAdView.loadAd(adRequest); // loadAd methods loads ads in Adview.

        AdView adView = new AdView(this); // create object of AdView
        adView.setAdSize(AdSize.BANNER);   // set ads size
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111"); // set ad unit id.
    }
}