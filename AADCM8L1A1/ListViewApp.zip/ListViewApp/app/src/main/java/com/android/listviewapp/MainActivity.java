package com.android.listviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

// This MainActivity class is created automatically when you create your project
public class MainActivity extends AppCompatActivity {
    ListView listView;  // declare Listview
    // Your app data, Array of String name of subjects.
    String[] subjectName = {"Math", "Computer", "Hindi", "Physic","Chemistry","Biology", "Coding","Android Development","Grammar","Web Development"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get listview by it's Id
        listView = findViewById(R.id.list_view);

        // using ArrayAdapter items are inserted into the list from array
        ArrayAdapter<String> subjectArray = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,subjectName);
        // setAdapter is used to conjoins an adapter with the list.
        listView.setAdapter(subjectArray);
    }
}