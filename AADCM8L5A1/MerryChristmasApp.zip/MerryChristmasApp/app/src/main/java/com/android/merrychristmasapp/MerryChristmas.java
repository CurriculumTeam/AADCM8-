package com.android.merrychristmasapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

// This MerryChristmas class is main class under this we write our code
public class MerryChristmas extends AppCompatActivity {
    LottieAnimationView lottieAnimationView;  // declare LottieAnimationView

    @Override   // onCreate method is the main method.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.merry_christmas);

        // finding lottieAnimationView by its ID
        lottieAnimationView = findViewById(R.id.merryChristmasAnimation);

        // Adding onClickListener on lottieView
        lottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // toast is used to display message so when you click on lottieAnimation you will see message as Merry Christmas!
                Toast.makeText(MerryChristmas.this, "Merry Christmas!!!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
