package com.android.merrychristmasapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// This MainActivity class is created when you create your project.
public class MainActivity extends AppCompatActivity {
    Button button;  // declare button

    @Override  // this is main method under which we write our code
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // finding button by its ID
        button = findViewById(R.id.surprise);
        // setting onClickListener on button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // when you click on button you will go to MerryChristmas with the help of intent.
                Intent intent = new Intent(MainActivity.this,MerryChristmas.class);
                startActivity(intent);  // starting intent
            }
        });
    }
}