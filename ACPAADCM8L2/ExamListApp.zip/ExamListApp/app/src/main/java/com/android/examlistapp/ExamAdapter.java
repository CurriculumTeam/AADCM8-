package com.android.examlistapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
// this is adapter class
public class ExamAdapter extends RecyclerView.Adapter<ExamAdapter.ViewHolder> {
    Context context;  // declare context
    ArrayList<Exam> data; // list of your app data

    // constructor of class ExamAdapter.
    public ExamAdapter(Context context, ArrayList<Exam> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override  // this method is used to create view
    public ExamAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // views are created with the help of LayoutInflater
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        // our custom_design is inflated.
        View view = layoutInflater.inflate(R.layout.custom_design,parent,false);
        // Instance of ViewHolder is created in which view is passed.
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder; // return viewHolder
    }

    @Override  // this method is used to bind the data or you can say insert the data into the views
    public void onBindViewHolder(@NonNull ExamAdapter.ViewHolder holder, int position) {
        // will set the data on particular position
        holder.subjectName.setText( data.get(position).subjectName);
        holder.examDate.setText(data.get(position).date);
    }

    @Override // this method is to get the number of items.
    public int getItemCount() {
        return data.size();
    }

    // this class will helps us to find the view or fetch the view from our custom_design layout
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView subjectName, examDate;  // declare all textview
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // find textview by it's Id
            subjectName = itemView.findViewById(R.id.subjectName);
            examDate = itemView.findViewById(R.id.examDate);
        }
    }
}
