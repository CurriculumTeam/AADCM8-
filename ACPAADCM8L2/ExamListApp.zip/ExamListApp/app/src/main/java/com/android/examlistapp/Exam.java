package com.android.examlistapp;

public class Exam {
    String subjectName;
    String date;

    public Exam(String subjectName, String date) {
        this.subjectName = subjectName;
        this.date = date;
    }
    public Exam() {  // empty constructor. select none while creating constructor.

    }
    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
