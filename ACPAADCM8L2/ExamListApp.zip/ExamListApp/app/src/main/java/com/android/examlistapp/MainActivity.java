package com.android.examlistapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;
// This class is automatically created when you created project.
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView; // declare RecyclerView
    ExamAdapter examAdapter;   // declare ExamAdapter
    ArrayList<Exam> data;     // declare array list

    @Override  // main method, under this we write our entire code.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data = new ArrayList<>();  // object of arraylist
        // getting recycler view by its ID
        recyclerView = findViewById(R.id.recyclerView);
        // You have to set Layout manager it is used to show how we want our recyclerview like linear or grid
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // create an object of recyclerAdapter and pass context and monthNames
        examAdapter = new ExamAdapter(this,data);
        data.add(new Exam("Math Exam","June 14"));
        data.add(new Exam("Biology Exam","June 15"));
        data.add(new Exam("Chemistry Exam","June 18"));
        data.add(new Exam("Computer Basic","June 20"));
        data.add(new Exam("Programming Exam","June 22"));
        data.add(new Exam("Physic Exam","June 26"));
        data.add(new Exam("English Exam","June 30"));
        recyclerView.setAdapter(examAdapter);  // setting adapter

    }
}