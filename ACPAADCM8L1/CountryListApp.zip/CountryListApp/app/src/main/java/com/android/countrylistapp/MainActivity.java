package com.android.countrylistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

// This MainActivity class is created automatically when you create your project
public class MainActivity extends AppCompatActivity {
    ListView listView;  // declare Listview
    // Your app data, Array of String name of countries.
    String[] countryName = {"India", "Nepal", "Germany", "Canada","Argentina","Australia", "Bangladesh","Afghanistan","Algeria","Belgium", "Bhutan", "Brazil", "China", "Colombia","Egypt", "France", "Indonesia"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get listview by it's Id
        listView = findViewById(R.id.list_view);

        // using ArrayAdapter items are inserted into the list from array
        ArrayAdapter<String> countryArray = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,countryName);
        // setAdapter is used to conjoins an adapter with the list.
        listView.setAdapter(countryArray);
    }
}
