package com.android.recyclerviewapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

// RecyclerAdapter class
public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    Context context;  // declare context
    String[] data;    // Array of your app data

    // Constructor
    public RecyclerAdapter(Context context, String[] data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override   // this method is used to create view
    public RecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // views are created with the help of LayoutInflater
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        // our custom_design is inflated.
        View view = layoutInflater.inflate(R.layout.custom_design,parent,false);
        // Instance of ViewHolder is created in which view is passed.
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder; // return viewHolder
    }

    @Override   // this method is used to bind the data or you can say insert the data into the views
    public void onBindViewHolder(@NonNull RecyclerAdapter.ViewHolder holder, int position) {
        // will set the data on particular position
        holder.monthName.setText(data[position]);
    }

    @Override  // this method is to get the number of items.
    public int getItemCount() {
        return data.length;   // return array's length
    }

    // this class will helps us to find the view or fetch the view from our custom_design layout
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView monthName;  // declare textview
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            monthName = itemView.findViewById(R.id.monthName);  // find textview by it's Id
        }
    }
}
