package com.android.recyclerviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

// This class is automatically created when you created project.
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;  // declare recyclerView
     RecyclerAdapter recyclerAdapter;  // declare recyclerAdapter

    // Your app data, array of strings
    String[] monthNames = {"January", "February", "March", "April", "May",
        "June", "July","August", "September","October","November", "December"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get recyclerView by it's Id
        recyclerView = findViewById(R.id.recyclerView);
        // You have to set Layout manager it is used to show how we want our recyclerview like linear or grid
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // create an object of recyclerAdapter and pass context and monthNames
        recyclerAdapter = new RecyclerAdapter(this,monthNames);
        recyclerView.setAdapter(recyclerAdapter);  //setting adapter
    }
}